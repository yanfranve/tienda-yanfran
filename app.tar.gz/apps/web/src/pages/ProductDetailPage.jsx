
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ShoppingCart, CreditCard, ArrowLeft, Loader2, ShieldCheck, Truck, RotateCcw, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/useCart.jsx';
import { getProduct, initializeCheckout } from '@/api/EcommerceApi';
import { cn } from '@/lib/utils';

const ProductDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addToCart } = useCart();
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);
        const data = await getProduct(id);
        setProduct(data);
        if (data.variants && data.variants.length > 0) {
          setSelectedVariant(data.variants[0]);
        }
      } catch (err) {
        setError(err.message || 'Error al cargar el producto');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchProduct();
    }
  }, [id]);

  const hasSale = useMemo(() => selectedVariant && selectedVariant.sale_price_in_cents !== null, [selectedVariant]);
  const displayPrice = useMemo(() => hasSale ? selectedVariant?.sale_price_formatted : selectedVariant?.price_formatted, [selectedVariant, hasSale]);
  const originalPrice = useMemo(() => hasSale ? selectedVariant?.price_formatted : null, [selectedVariant, hasSale]);

  const handleAddToCart = async () => {
    if (!product || !selectedVariant) return;
    
    try {
      await addToCart(product, selectedVariant, quantity, selectedVariant.inventory_quantity);
      toast({
        title: "¡Agregado al carrito!",
        description: `${product.title} (${selectedVariant.title}) se ha añadido a tu carrito.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleBuyNow = async () => {
    if (!product || !selectedVariant) return;
    
    try {
      setIsCheckingOut(true);
      const items = [{
        variant_id: selectedVariant.id,
        quantity: quantity,
      }];

      const successUrl = `${window.location.origin}/success`;
      const cancelUrl = window.location.href;

      const { url } = await initializeCheckout({ items, successUrl, cancelUrl });
      window.location.href = url;
    } catch (error) {
      toast({
        title: "Error al procesar",
        description: "Hubo un problema al iniciar el pago. Por favor intenta nuevamente.",
        variant: "destructive",
      });
      setIsCheckingOut(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <Skeleton className="aspect-square rounded-2xl w-full" />
          <div className="space-y-6">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <h2 className="text-2xl font-bold text-destructive mb-4">Producto no encontrado</h2>
        <p className="text-muted-foreground mb-8">{error || "El producto que buscas no existe o no está disponible."}</p>
        <Button onClick={() => navigate('/')} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-2" /> Volver al inicio
        </Button>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${product.title} - Yanfran`}</title>
        <meta name="description" content={product.subtitle || `Compra ${product.title} en Yanfran.`} />
      </Helmet>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-8 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4 mr-2" /> Volver
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Image Gallery */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-4"
          >
            <div className="aspect-square rounded-2xl overflow-hidden bg-muted border border-border relative">
              <img 
                src={product.image || "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80"} 
                alt={product.title}
                className="w-full h-full object-cover"
              />
              {hasSale && (
                <Badge className="absolute top-4 right-4 bg-destructive text-destructive-foreground text-sm px-3 py-1">
                  Oferta
                </Badge>
              )}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col"
          >
            {product.ribbon_text && (
              <Badge variant="secondary" className="w-fit mb-4 bg-accent/10 text-accent hover:bg-accent/20">
                {product.ribbon_text}
              </Badge>
            )}
            
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 leading-tight">
              {product.title}
            </h1>
            
            <div className="flex items-baseline gap-4 mb-6">
              <span className="text-3xl md:text-4xl font-bold gradient-text">
                {displayPrice}
              </span>
              {hasSale && (
                <span className="text-lg text-muted-foreground line-through">
                  {originalPrice}
                </span>
              )}
            </div>

            <div 
              className="prose prose-sm md:prose-base dark:prose-invert text-muted-foreground mb-8"
              dangerouslySetInnerHTML={{ __html: product.description || product.subtitle || 'Sin descripción disponible.' }}
            />

            {/* Variants Selection */}
            {product.variants && product.variants.length > 1 && (
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-foreground">
                    Color / Variante
                  </h3>
                  <span className="text-sm text-muted-foreground">
                    Seleccionado: <span className="font-medium text-foreground">{selectedVariant?.title}</span>
                  </span>
                </div>
                <div className="flex flex-wrap gap-3">
                  {product.variants.map((variant) => {
                    const isSelected = selectedVariant?.id === variant.id;
                    return (
                      <button
                        key={variant.id}
                        onClick={() => setSelectedVariant(variant)}
                        className={cn(
                          "relative flex items-center justify-center px-4 py-2.5 rounded-xl border text-sm font-medium transition-all duration-200",
                          isSelected 
                            ? "border-primary bg-primary/5 text-primary ring-1 ring-primary ring-offset-1" 
                            : "border-border bg-background text-muted-foreground hover:border-primary/40 hover:bg-muted"
                        )}
                      >
                        {isSelected && <Check className="w-4 h-4 mr-2" />}
                        {variant.title}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quantity and Actions */}
            <div className="space-y-4 mt-auto pt-8 border-t border-border">
              <div className="flex items-center gap-4 mb-6">
                <span className="text-sm font-medium text-foreground">Cantidad:</span>
                <div className="flex items-center border border-input rounded-lg bg-background">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="h-10 w-10 rounded-none rounded-l-lg"
                  >
                    -
                  </Button>
                  <span className="w-12 text-center font-medium">{quantity}</span>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                    className="h-10 w-10 rounded-none rounded-r-lg"
                  >
                    +
                  </Button>
                </div>
                {selectedVariant?.manage_inventory && (
                  <span className="text-sm text-muted-foreground">
                    {selectedVariant.inventory_quantity} disponibles
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Button 
                  onClick={handleAddToCart}
                  variant="outline"
                  size="lg"
                  className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground h-14 text-lg"
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Agregar al carrito
                </Button>
                <Button 
                  onClick={handleBuyNow}
                  disabled={isCheckingOut}
                  size="lg"
                  className="w-full gradient-primary text-white h-14 text-lg hover:opacity-90"
                >
                  {isCheckingOut ? (
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  ) : (
                    <CreditCard className="w-5 h-5 mr-2" />
                  )}
                  Comprar ahora
                </Button>
              </div>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t border-border">
              <div className="flex flex-col items-center text-center gap-2">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                </div>
                <span className="text-xs text-muted-foreground font-medium">Pago Seguro</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <Truck className="w-5 h-5 text-primary" />
                </div>
                <span className="text-xs text-muted-foreground font-medium">Envío Rápido</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <RotateCcw className="w-5 h-5 text-primary" />
                </div>
                <span className="text-xs text-muted-foreground font-medium">Garantía</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ProductDetailPage;
